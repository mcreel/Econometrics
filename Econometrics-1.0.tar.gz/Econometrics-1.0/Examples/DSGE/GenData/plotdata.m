load dsgedata;
plot(dsgedata);
legend("y", "c", "n", "r", "w");
