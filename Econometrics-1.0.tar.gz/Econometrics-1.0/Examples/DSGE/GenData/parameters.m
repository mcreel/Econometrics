lb_param_ub = [
0.20   	0.33   	0.4		% alpha
0.95    0.99   	1 	    % beta
0.01    0.025   0.1		% delta
0.0	    2      	5		% gam
0    	0.9   	1	    % rho1
0       0.02 	0.1		% sigma1
0    	0.7     1       % rho2
0	    0.01  	0.1		% sigma2
6/24    8/24	9/24	% nss
];


