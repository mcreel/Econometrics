function theta = parameterize(theta)
#	theta(1,:) = 1 / (1 + exp(-theta(1,:)));
#	theta(2,:) = exp(theta(2,:));
#	theta(3,:) = exp(theta(3,:));
endfunction
