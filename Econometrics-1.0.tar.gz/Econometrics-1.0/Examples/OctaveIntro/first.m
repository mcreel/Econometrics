# here's a comment - Octave doesn't do anything with this

# Here we define a string variable, and display it to the screen
a = "hello world";
disp(a);

# Here's another way to accomplish the same thing
printf("hello world");


# If a line does not end with a semicolon, the result is displayed to
# the screen:
b = 2+2

# With a semicolon, the result is not displayed
c = 2+2;

# This displays it
c


# To run this program, press CTRL-ALT-o
 
