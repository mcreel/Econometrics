                                                         # number of combinations of k objects that can be formed from
# a set of n objects
function c = combinations(n, k)
	c = bincoeff(n,k);
endfunction
