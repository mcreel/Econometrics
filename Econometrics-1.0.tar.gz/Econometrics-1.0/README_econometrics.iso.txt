If using the econometrics.iso image with virtualization

1. set your keyboard layout using the command "setxkmap <your country code>". So, to set a
Spanish keyboard, open a terminal and enter  "setxkbmap es" (without quotes) at the prompt.
2. open a terminal, go to /home/user/Econometrics, and run setup_econometrics
3. save the state of the machine, so that you don't have to repeat these steps

 
